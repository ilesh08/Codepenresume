/**

Resume concept based on the Dribbble by John Wilson http://dribbble.com/shots/900308-Resume?list=users

**/

$(document).ready(function() {
  $('#item1').animate({
     borderBottomWidth: '200px'}, 1000);
  $('#item2').animate({
     borderBottomWidth: '50px'}, 1000);
  $('#item3').animate({
     borderBottomWidth: '15px'}, 1000);
  $('#item4').animate({
     borderBottomWidth: '37.5px'}, 1000);
  $('#item5').animate({
     borderBottomWidth: '37.5px'}, 1000);
  $('#item6').animate({
     borderBottomWidth: '100px'}, 1000);
  $('#item7').animate({
     borderBottomWidth: '62.5px'}, 1000);
})