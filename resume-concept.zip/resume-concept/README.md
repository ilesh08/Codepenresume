# Resume Concept

A Pen created on CodePen.

Original URL: [https://codepen.io/bphillips201/pen/AxLKby](https://codepen.io/bphillips201/pen/AxLKby).

Based on the dribbble by John Wilson http://dribbble.com/shots/900308-Resume?list=users